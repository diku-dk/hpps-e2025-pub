#include "stdio.h"
#include "bitvec8.h"

bitvec8 bitvec8_from_int(unsigned int x) {
  return 0xFF & x;
}

unsigned int bitvec8_to_int(bitvec8 v) {
  return v;
}

struct add_result {
  bitvec8 s;
  bitvec8 c;
};

struct add_result sum_and_carry(bitvec8 x, bitvec8 y) {
  struct add_result r;
  r.s = x ^ y ;
  r.c = (x & y) << 1;
  return r;
}

bitvec8 bitvec8_add(bitvec8 x, bitvec8 y) {
  struct add_result r0 = sum_and_carry(x, y);
  struct add_result r1 = sum_and_carry(r0.s, r0.c);
  struct add_result r2 = sum_and_carry(r1.s, r1.c);
  struct add_result r3 = sum_and_carry(r2.s, r2.c);
  struct add_result r4 = sum_and_carry(r3.s, r3.c);
  struct add_result r5 = sum_and_carry(r4.s, r4.c);
  struct add_result r6 = sum_and_carry(r5.s, r5.c);
  struct add_result r7 = sum_and_carry(r6.s, r6.c);
  return (r7.s ^ r7.c) & 0xFF;
}

bitvec8 bitvec8_negate(bitvec8 x) {
  return bitvec8_add(~x, 0x01);
}


bitvec8 mul_step(bitvec8 result, bitvec8 x, bitvec8 y, int bit_pos) {
  bitvec8 mask = -(!!(y & (1 << bit_pos)));  
  return bitvec8_add(result,  (x & mask) << bit_pos);
}

bitvec8 bitvec8_mul(bitvec8 x, bitvec8 y) {
  bitvec8 result = 0;
  result = mul_step(result, x, y, 0);
  result = mul_step(result, x, y, 1);
  result = mul_step(result, x, y, 2);
  result = mul_step(result, x, y, 3);
  result = mul_step(result, x, y, 4);
  result = mul_step(result, x, y, 5);
  result = mul_step(result, x, y, 6);
  result = mul_step(result, x, y, 7);
  return result & 0xFF;
}

void bitvec8_print(bitvec8 v) {
  putchar('0' + ((v>>7) & 1));
  putchar('0' + ((v>>6) & 1));
  putchar('0' + ((v>>5) & 1));
  putchar('0' + ((v>>4) & 1));
  putchar('0' + ((v>>3) & 1));
  putchar('0' + ((v>>2) & 1));
  putchar('0' + ((v>>1) & 1));
  putchar('0' + (v & 1));
}
