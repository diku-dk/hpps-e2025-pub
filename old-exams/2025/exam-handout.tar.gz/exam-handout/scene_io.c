#include "scene.h"
#include "scene_io.h"

struct loaded_scene {
  int dummy; // TODO
};

size_t scene_get_num_objects(struct loaded_scene* scene) {
  assert(0);
}

struct object* scene_get_objects(struct loaded_scene* scene) {
  assert(0);
}


struct vec* scene_get_lookfrom(struct loaded_scene* scene) {
  assert(0);
}

struct vec* scene_get_lookat(struct loaded_scene* scene) {
  assert(0);
}

void free_loaded_scene(struct loaded_scene* scene) {
  assert(0);
}


struct loaded_scene* load_scene(const char *fname) {
  assert(0);
}

int store_scene(char* fname,
                size_t num_objects, struct object *objects,
                struct vec lookfrom, struct vec lookat) {
  assert(0);
}
