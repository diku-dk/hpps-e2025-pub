#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "scene_io.h"

int main(int argc, char** argv) {
  assert(argc == 3);

  const char *scene = argv[2];

  struct vec lookfrom, lookat;
  size_t num_materials, num_objects;
  struct material *materials;
  struct object *objects;
  scene_by_name(scene, &lookfrom, &lookat,
                &num_materials, &materials,
                &num_objects, &objects);

  if (store_scene(argv[1], num_objects, objects, lookfrom, lookat) != 0) {
    fprintf(stderr, "Failed to store scene in %s\n", argv[1]);
  }
  free(materials);
  free(objects);
}
