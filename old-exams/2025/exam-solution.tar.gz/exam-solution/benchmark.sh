#!/bin/sh
#
# Benchmarking script.

make CFLAGS='-Wall -Wextra -pedantic -O3 -lm -fopenmp' -B -j

calc() {
    awk "BEGIN {print $1}"
}

get_rendering() {
    awk '/Rendering: / {print $2}'
}

get_bvh_and_rendering() {
    awk '/Rendering: / {x=$2} /BVH construction: / {y=$2} END {print $1+$2}'
}


1b() {
    echo
    echo '1b - strong scaling of ray'

    base=$(OMP_NUM_THREADS=1 ./ray /dev/null 100 100 10 rgbbox | get_rendering)

    echo "Threads | Runtime | Speedup"
    for t in 1 2 4 8 16; do
        seconds=$(OMP_NUM_THREADS=$t ./ray /dev/null 100 100 10 rgbbox | get_rendering)
        printf "%7d | %6.3fs | %.2f\n" $t $seconds $(calc "$base/$seconds")
    done

    echo
    echo '1b - weak scaling of ray'

    echo "Threads | Runtime | Speedup"
    for t in 1 2 4 8 16; do
        base=$(OMP_NUM_THREADS=1 ./ray /dev/null 100 $((100 * $t)) 10 rgbbox | get_rendering)
        seconds=$(OMP_NUM_THREADS=$t ./ray /dev/null 100 $((100 * $t)) 10 rgbbox | get_rendering)
        printf "%7d | %6.3fs | %5.2f\n" $t $seconds $(calc "$base/$seconds")
    done
}

3a() {
    echo
    echo '3a - strong scaling of ray_bvh'

    base=$(OMP_NUM_THREADS=1 ./ray_bvh /dev/null 500 500 10 rgbbox | get_bvh_and_rendering)

    echo "Threads | Runtime | Speedup"
    for t in 1 2 4 8 16; do
        seconds=$(OMP_NUM_THREADS=$t ./ray_bvh /dev/null 500 500 10 rgbbox | get_bvh_and_rendering)
        printf "%7d | %6.3fs | %.2f\n" $t $seconds $(calc "$base/$seconds")
    done

    echo
    echo '3a - weak scaling of ray_bvh'

    echo "Threads | Runtime | Speedup"
    for t in 1 2 4 8 16; do
        base=$(OMP_NUM_THREADS=1 ./ray_bvh /dev/null 500 $((500 * $t)) 10 rgbbox | get_bvh_and_rendering)
        seconds=$(OMP_NUM_THREADS=$t ./ray_bvh /dev/null 500 $((500 * $t)) 10 rgbbox | get_bvh_and_rendering)
        printf "%7d | %6.3fs | %5.2f\n" $t $seconds $(calc "$base/$seconds")
    done
}

3c() {
    OMP_NUM_THREADS=1 ./ray /dev/null 1 1 10 rgbbox
    OMP_NUM_THREADS=1 ./ray_bvh /dev/null 1 1 10 rgbbox
}

1b
3a
3c
