// This program performs tests of the scene_io facilities. The program takes one
// argument: the number of the test to run. This means this program must be run
// multiple times in order to perform all tests. That is to handle the case
// where a bug in a handin causes the process to abort.

#include <stdio.h>
#include <assert.h>
#include <string.h>

#include "scene.h"
#include "scene_io.h"

struct vec lookfrom = {3, 14, 17};
struct vec lookat = {6, 7, 2};

int vec_eql(struct vec a, struct vec b) {
  return a.x == b.x && a.y == b.y && a.z == b.z;
}

int material_eql(struct material a, struct material b) {
  if (a.type != b.type) {
    return 0;
  }

  switch (a.type) {
  case LAMBERTIAN:
    return vec_eql(a.lambertian.albedo, b.lambertian.albedo);
  case METAL:
    return vec_eql(a.metal.albedo, b.metal.albedo) &&
      a.metal.fuzz == b.metal.fuzz;
  case DIELECTRIC:
    return a.dielectric.ref_idx == b.dielectric.ref_idx;
  default:
    abort();
  }
}

int object_eql(struct object a, struct object b) {
  if (a.type != b.type) {
    return 0;
  }

  switch (a.type) {
  case SPHERE:
    return vec_eql(a.sphere.centre, b.sphere.centre)
      && a.sphere.radius == b.sphere.radius
      && material_eql(*a.sphere.material, *b.sphere.material);
  case XY_RECTANGLE:
    return a.xy_rectangle.x0 == b.xy_rectangle.x0 &&
      a.xy_rectangle.x1 == b.xy_rectangle.x1 &&
      a.xy_rectangle.y0 == b.xy_rectangle.y0 &&
      a.xy_rectangle.y1 == b.xy_rectangle.y1 &&
      a.xy_rectangle.k == b.xy_rectangle.k &&
      material_eql(*a.xy_rectangle.material, *b.xy_rectangle.material);
  case XZ_RECTANGLE:
    return a.xz_rectangle.x0 == b.xz_rectangle.x0 &&
      a.xz_rectangle.x1 == b.xz_rectangle.x1 &&
      a.xz_rectangle.z0 == b.xz_rectangle.z0 &&
      a.xz_rectangle.z1 == b.xz_rectangle.z1 &&
      a.xz_rectangle.k == b.xz_rectangle.k &&
      material_eql(*a.xz_rectangle.material, *b.xz_rectangle.material);
  case YZ_RECTANGLE:
    return a.yz_rectangle.y0 == b.yz_rectangle.y0 &&
      a.yz_rectangle.y1 == b.yz_rectangle.y1 &&
      a.yz_rectangle.z0 == b.yz_rectangle.z0 &&
      a.yz_rectangle.z1 == b.yz_rectangle.z1 &&
      a.yz_rectangle.k == b.yz_rectangle.k &&
      material_eql(*a.yz_rectangle.material, *b.yz_rectangle.material);
  default:
    abort();
  }
}

void test0(void) {
  printf("Storing and restoring single sphere\n");
  struct material material;
  material.type = DIELECTRIC;
  material.dielectric.ref_idx = 0;
  struct object objects[1];
  objects[0].type = SPHERE;
  objects[0].sphere.centre.x = 1;
  objects[0].sphere.centre.y = 2;
  objects[0].sphere.centre.z = 3;
  objects[0].sphere.radius = 10;
  objects[0].sphere.material = &material;

  assert(store_scene("test0.scene", 1, objects, lookfrom, lookat) == 0);
  struct loaded_scene *loaded = load_scene("test0.scene");

  assert(scene_get_num_objects(loaded) == 1);
  struct object *objects_loaded = scene_get_objects(loaded);
  assert(memcmp(scene_get_lookfrom(loaded), &lookfrom, sizeof(lookfrom)) == 0);
  assert(memcmp(scene_get_lookat(loaded), &lookat, sizeof(lookat)) == 0);

  assert(objects_loaded[0].type == SPHERE);
  assert(objects_loaded[0].sphere.radius == objects[0].sphere.radius);
  assert(vec_eql(objects_loaded[0].sphere.centre, objects[0].sphere.centre));

  free_loaded_scene(loaded);
}

void test1(void) {
  printf("Storing and restoring single xy_rectangle\n");
  struct material material;
  material.type = DIELECTRIC;
  material.dielectric.ref_idx = 0;
  struct object objects[1];
  objects[0].type = XY_RECTANGLE;
  objects[0].xy_rectangle.x0 = 1;
  objects[0].xy_rectangle.x1 = 2;
  objects[0].xy_rectangle.y0 = 3;
  objects[0].xy_rectangle.y1 = 4;
  objects[0].xy_rectangle.k = 5;
  objects[0].xy_rectangle.material = &material;

  assert(store_scene("test1.scene", 1, objects, lookfrom, lookat) == 0);
  struct loaded_scene *loaded = load_scene("test1.scene");

  assert(scene_get_num_objects(loaded) == 1);
  struct object *objects_loaded = scene_get_objects(loaded);
  assert(memcmp(scene_get_lookfrom(loaded), &lookfrom, sizeof(lookfrom)) == 0);
  assert(memcmp(scene_get_lookat(loaded), &lookat, sizeof(lookat)) == 0);

  assert(objects_loaded[0].type == XY_RECTANGLE);
  assert(objects_loaded[0].xy_rectangle.x0 == objects[0].xy_rectangle.x0);
  assert(objects_loaded[0].xy_rectangle.x1 == objects[0].xy_rectangle.x1);
  assert(objects_loaded[0].xy_rectangle.y0 == objects[0].xy_rectangle.y0);
  assert(objects_loaded[0].xy_rectangle.y1 == objects[0].xy_rectangle.y1);
  assert(objects_loaded[0].xy_rectangle.k == objects[0].xy_rectangle.k);

  free_loaded_scene(loaded);
}

void test2(void) {
  printf("Storing and restoring single xz_rectangle\n");
  struct material material;
  material.type = DIELECTRIC;
  material.dielectric.ref_idx = 0;
  struct object objects[1];
  objects[0].type = XZ_RECTANGLE;
  objects[0].xz_rectangle.x0 = 1;
  objects[0].xz_rectangle.x1 = 2;
  objects[0].xz_rectangle.z0 = 3;
  objects[0].xz_rectangle.z1 = 4;
  objects[0].xz_rectangle.k = 5;
  objects[0].xz_rectangle.material = &material;

  assert(store_scene("test2.scene", 1, objects, lookfrom, lookat) == 0);
  struct loaded_scene *loaded = load_scene("test2.scene");

  assert(scene_get_num_objects(loaded) == 1);
  struct object *objects_loaded = scene_get_objects(loaded);
  assert(memcmp(scene_get_lookfrom(loaded), &lookfrom, sizeof(lookfrom)) == 0);
  assert(memcmp(scene_get_lookat(loaded), &lookat, sizeof(lookat)) == 0);

  assert(objects_loaded[0].type == XZ_RECTANGLE);
  assert(objects_loaded[0].xz_rectangle.x0 == objects[0].xz_rectangle.x0);
  assert(objects_loaded[0].xz_rectangle.x1 == objects[0].xz_rectangle.x1);
  assert(objects_loaded[0].xz_rectangle.z0 == objects[0].xz_rectangle.z0);
  assert(objects_loaded[0].xz_rectangle.z1 == objects[0].xz_rectangle.z1);
  assert(objects_loaded[0].xz_rectangle.k == objects[0].xz_rectangle.k);

  free_loaded_scene(loaded);
}

void test3(void) {
  printf("Storing and restoring single yz_rectangle\n");
  struct material material;
  material.type = DIELECTRIC;
  material.dielectric.ref_idx = 0;
  struct object objects[1];
  objects[0].type = YZ_RECTANGLE;
  objects[0].yz_rectangle.y0 = 1;
  objects[0].yz_rectangle.y1 = 2;
  objects[0].yz_rectangle.y0 = 3;
  objects[0].yz_rectangle.y1 = 4;
  objects[0].yz_rectangle.k = 5;
  objects[0].yz_rectangle.material = &material;

  assert(store_scene("test3.scene", 1, objects, lookfrom, lookat) == 0);
  struct loaded_scene *loaded = load_scene("test3.scene");

  assert(scene_get_num_objects(loaded) == 1);
  struct object *objects_loaded = scene_get_objects(loaded);
  assert(memcmp(scene_get_lookfrom(loaded), &lookfrom, sizeof(lookfrom)) == 0);
  assert(memcmp(scene_get_lookat(loaded), &lookat, sizeof(lookat)) == 0);

  assert(objects_loaded[0].type == YZ_RECTANGLE);
  assert(objects_loaded[0].yz_rectangle.y0 == objects[0].yz_rectangle.y0);
  assert(objects_loaded[0].yz_rectangle.y1 == objects[0].yz_rectangle.y1);
  assert(objects_loaded[0].yz_rectangle.z0 == objects[0].yz_rectangle.z0);
  assert(objects_loaded[0].yz_rectangle.z1 == objects[0].yz_rectangle.z1);
  assert(objects_loaded[0].yz_rectangle.k == objects[0].yz_rectangle.k);

  free_loaded_scene(loaded);
}

void test4(void) {
  printf("Storing and restoring lambertian\n");
  struct material material;
  material.type = LAMBERTIAN;
  material.lambertian.albedo.x = 1;
  material.lambertian.albedo.y = 2;
  material.lambertian.albedo.z = 3;
  struct object objects[1];
  objects[0].type = SPHERE;
  objects[0].sphere.centre.x = 1;
  objects[0].sphere.centre.y = 2;
  objects[0].sphere.centre.z = 3;
  objects[0].sphere.radius = 10;
  objects[0].sphere.material = &material;

  assert(store_scene("test4.scene", 1, objects, lookfrom, lookat) == 0);
  struct loaded_scene *loaded = load_scene("test4.scene");

  assert(scene_get_num_objects(loaded) == 1);
  struct object *objects_loaded = scene_get_objects(loaded);
  assert(memcmp(scene_get_lookfrom(loaded), &lookfrom, sizeof(lookfrom)) == 0);
  assert(memcmp(scene_get_lookat(loaded), &lookat, sizeof(lookat)) == 0);

  assert(objects_loaded[0].type == SPHERE);
  assert(material_eql(*objects_loaded[0].sphere.material, *objects[0].sphere.material));

  free_loaded_scene(loaded);
}

void test5(void) {
  printf("Storing and restoring metal\n");
  struct material material;
  material.type = METAL;
  material.metal.albedo.x = 1;
  material.metal.albedo.y = 2;
  material.metal.albedo.z = 3;
  material.metal.fuzz = 4;
  struct object objects[1];
  objects[0].type = SPHERE;
  objects[0].sphere.centre.x = 1;
  objects[0].sphere.centre.y = 2;
  objects[0].sphere.centre.z = 3;
  objects[0].sphere.radius = 10;
  objects[0].sphere.material = &material;

  assert(store_scene("test5.scene", 1, objects, lookfrom, lookat) == 0);
  struct loaded_scene *loaded = load_scene("test5.scene");

  assert(scene_get_num_objects(loaded) == 1);
  struct object *objects_loaded = scene_get_objects(loaded);
  assert(memcmp(scene_get_lookfrom(loaded), &lookfrom, sizeof(lookfrom)) == 0);
  assert(memcmp(scene_get_lookat(loaded), &lookat, sizeof(lookat)) == 0);

  assert(objects_loaded[0].type == SPHERE);
  assert(material_eql(*objects_loaded[0].sphere.material, *objects[0].sphere.material));

  free_loaded_scene(loaded);
}

void test6(void) {
  printf("Storing and restoring dielectric\n");
  struct material material;
  material.type = DIELECTRIC;
  material.dielectric.ref_idx = 0;
  struct object objects[1];
  objects[0].type = SPHERE;
  objects[0].sphere.centre.x = 1;
  objects[0].sphere.centre.y = 2;
  objects[0].sphere.centre.z = 3;
  objects[0].sphere.radius = 10;
  objects[0].sphere.material = &material;

  assert(store_scene("test6.scene", 1, objects, lookfrom, lookat) == 0);
  struct loaded_scene *loaded = load_scene("test6.scene");

  assert(scene_get_num_objects(loaded) == 1);
  struct object *objects_loaded = scene_get_objects(loaded);
  assert(memcmp(scene_get_lookfrom(loaded), &lookfrom, sizeof(lookfrom)) == 0);
  assert(memcmp(scene_get_lookat(loaded), &lookat, sizeof(lookat)) == 0);

  assert(objects_loaded[0].type == SPHERE);
  assert(material_eql(*objects_loaded[0].sphere.material, *objects[0].sphere.material));

  free_loaded_scene(loaded);
}

void test7(void) {
  printf("Storing and restoring empty scene\n");

  assert(store_scene("test7.scene", 0, NULL, lookfrom, lookat) == 0);
  struct loaded_scene *loaded = load_scene("test7.scene");

  assert(scene_get_num_objects(loaded) == 0);

  free_loaded_scene(loaded);
}

void test8(void) {
  printf("Storing and restoring lookat (and empty scene)\n");

  assert(store_scene("test8.scene", 0, NULL, lookfrom, lookat) == 0);
  struct loaded_scene *loaded = load_scene("test8.scene");

  assert(scene_get_num_objects(loaded) == 0);
  assert(vec_eql(lookat, *scene_get_lookat(loaded)));

  free_loaded_scene(loaded);
}

void test9(void) {
  printf("Storing and restoring lookfrom (and empty scene)\n");

  assert(store_scene("test9.scene", 0, NULL, lookfrom, lookat) == 0);
  struct loaded_scene *loaded = load_scene("test9.scene");

  assert(scene_get_num_objects(loaded) == 0);
  assert(vec_eql(lookfrom, *scene_get_lookfrom(loaded)));

  free_loaded_scene(loaded);
}

void test10(void) {
  printf("Storing and restoring multiple objects and materials (nice)\n");
  size_t num_materials, num_objects;
  struct material *materials;
  struct object *objects;

  assert(scene_by_name("nice", &lookfrom, &lookat,
                       &num_materials, &materials,
                       &num_objects, &objects));

  assert(store_scene("test10.scene", num_objects, objects, lookfrom, lookat) == 0);
  struct loaded_scene *loaded = load_scene("test10.scene");

  assert(scene_get_num_objects(loaded) == num_objects);

  bool used[num_objects];
  for (size_t i = 0; i < num_objects; i++) {
    used[i]= false;
  }

  for (size_t i = 0; i < num_objects; i++) {
    bool found = false;
    for (size_t j = 0; j < num_objects; j++) {
      if (!used[j] && object_eql(objects[i], scene_get_objects(loaded)[j])) {
        found = true;
        used[j] = true;
        break;
      }
    }
    if (!found) {
      printf("Missing object:\n");
      describe_object(&objects[i]);
    }
  }

  free(materials);
  free(objects);
  free_loaded_scene(loaded);
}

void test11(void) {
  printf("Deduplication of materials\n");
  size_t num_materials, num_objects;
  struct material *materials;
  struct object *objects;

  assert(scene_by_name("rgbbox", &lookfrom, &lookat,
                       &num_materials, &materials,
                       &num_objects, &objects));

  assert(store_scene("test11.scene", num_objects, objects, lookfrom, lookat) == 0);
  struct loaded_scene *loaded = load_scene("test11.scene");

  assert(scene_get_num_objects(loaded) == num_objects);

  size_t num_materials_seen = 0;
  struct material* seen[num_objects];
  for (size_t i = 0; i < num_objects; i++) {
    seen[i] = NULL;
  }

  for (size_t i = 0; i < num_objects; i++) {
    struct material* material = object_material(&scene_get_objects(loaded)[i]);
    size_t j;
    for (j = 0; j < num_materials_seen; j++) {
      if (material == seen[j]) {
        break;
      }
    }
    if (j == num_materials_seen) {
      seen[j] = material;
      num_materials_seen++;
    }
  }

  assert(num_materials_seen == 4);

  free(materials);
  free(objects);
  free_loaded_scene(loaded);
}

void test12(void) {
  printf("Storing (empty) scene in inaccessible file\n");

  assert(store_scene("/test12.scene", 0, NULL, lookfrom, lookat) != 0);
}

void test13(void) {
  printf("Loading scene from inaccessible file\n");

  assert(load_scene("/root/doesnotexist") == NULL);
}

typedef void (*test_fn)(void);
static test_fn tests[] = {
  test0,
  test1,
  test2,
  test3,
  test4,
  test5,
  test6,
  test7,
  test8,
  test9,
  test10,
  test11,
  test12,
  test13
};
static int num_tests = sizeof(tests) / sizeof(tests[0]);

int main(int argc, char** argv) {
  assert(argc == 2);
  int i = atoi(argv[1]);
  assert(i >= 0 && i < num_tests);
  tests[i]();
}
