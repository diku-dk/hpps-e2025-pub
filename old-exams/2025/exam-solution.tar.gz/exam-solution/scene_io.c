#include "scene.h"
#include "scene_io.h"

struct loaded_scene {
  size_t num_materials, num_objects;
  struct material *materials;
  struct object *objects;
  struct vec lookfrom, lookat;
};

size_t scene_get_num_objects(struct loaded_scene* scene) {
  return scene->num_objects;
}

struct object* scene_get_objects(struct loaded_scene* scene) {
  return scene->objects;
}


struct vec* scene_get_lookfrom(struct loaded_scene* scene) {
  return &scene->lookfrom;
}

struct vec* scene_get_lookat(struct loaded_scene* scene) {
  return &scene->lookat;
}

void free_loaded_scene(struct loaded_scene* scene) {
  free(scene->materials);
  free(scene->objects);
  free(scene);
}

static int load_int(FILE *f, int *x) {
  if (fread(x, sizeof(int), 1, f) != 1) {
    return 1;
  }
  return 0;
}

static int load_double(FILE *f, double *x) {
  if (fread(x, sizeof(double), 1, f) != 1) {
    return 1;
  }
  return 0;
}

static int load_size_t(FILE *f, size_t *x) {
  if (fread(x, sizeof(size_t), 1, f) != 1) {
    return 1;
  }
  return 0;
}

static int load_vec(FILE *f, struct vec *v) {
  if (load_double(f, &v->x) != 0) {
    return 1;
  }
  if (load_double(f, &v->y) != 0) {
    return 1;
  }
  if (load_double(f, &v->z) != 0) {
    return 1;
  }
  return 0;
}

static int load_material(FILE *f, struct material* material) {
  int type;
  if (load_int(f, &type) != 0) {
    return 1;
  }
  switch (type) {
  case LAMBERTIAN:
    material->type = LAMBERTIAN;
    if (load_vec(f, &material->lambertian.albedo) != 0) {
      return 1;
    }
    return 0;
  case METAL:
    material->type = METAL;
    if (load_vec(f, &material->metal.albedo) != 0) {
      return 1;
    }
    if (load_double(f, &material->metal.fuzz) != 0) {
      return 1;
    }
    return 0;
  case DIELECTRIC:
    material->type = DIELECTRIC;
    if (load_double(f, &material->dielectric.ref_idx) != 0) {
      return 1;
    }
    return 0;
  default:
    abort();
  }
}

static int load_sphere(FILE *f,
                       size_t num_materials, struct material *materials,
                       struct object* object) {
  size_t idx;
  object->type = SPHERE;
  if (load_vec(f, &object->sphere.centre) != 0) {
    return 1;
  }
  if (load_double(f, &object->sphere.radius) != 0) {
    return 1;
  }
  if (load_size_t(f, &idx) != 0 || idx >= num_materials) {
    return 1;
  }
  object->sphere.material = &materials[idx];
  return 0;
}

static int load_xy_rectangle(FILE *f,
                             size_t num_materials, struct material *materials,
                             struct object* object) {
  size_t idx;
  object->type = XY_RECTANGLE;
  if (load_double(f, &object->xy_rectangle.x0) != 0) {
    return 1;
  }
  if (load_double(f, &object->xy_rectangle.x1) != 0) {
    return 1;
  }
  if (load_double(f, &object->xy_rectangle.y0) != 0) {
    return 1;
  }
  if (load_double(f, &object->xy_rectangle.y1) != 0) {
    return 1;
  }
  if (load_double(f, &object->xy_rectangle.k) != 0) {
    return 1;
  }
  if (load_size_t(f, &idx) != 0 || idx >= num_materials) {
    return 1;
  }
  object->xy_rectangle.material = &materials[idx];
  return 0;
}

static int load_xz_rectangle(FILE *f,
                             size_t num_materials, struct material *materials,
                             struct object* object) {
  size_t idx;
  object->type = XZ_RECTANGLE;
  if (load_double(f, &object->xz_rectangle.x0) != 0) {
    return 1;
  }
  if (load_double(f, &object->xz_rectangle.x1) != 0) {
    return 1;
  }
  if (load_double(f, &object->xz_rectangle.z0) != 0) {
    return 1;
  }
  if (load_double(f, &object->xz_rectangle.z1) != 0) {
    return 1;
  }
  if (load_double(f, &object->xz_rectangle.k) != 0) {
    return 1;
  }
  if (load_size_t(f, &idx) != 0 || idx >= num_materials) {
    return 1;
  }
  object->xz_rectangle.material = &materials[idx];
  return 0;
}

static int load_yz_rectangle(FILE *f,
                             size_t num_materials, struct material *materials,
                             struct object* object) {
  size_t idx;
  object->type = YZ_RECTANGLE;
  if (load_double(f, &object->yz_rectangle.y0) != 0) {
    return 1;
  }
  if (load_double(f, &object->yz_rectangle.y1) != 0) {
    return 1;
  }
  if (load_double(f, &object->yz_rectangle.z0) != 0) {
    return 1;
  }
  if (load_double(f, &object->yz_rectangle.z1) != 0) {
    return 1;
  }
  if (load_double(f, &object->yz_rectangle.k) != 0) {
    return 1;
  }
  if (load_size_t(f, &idx) != 0 || idx >= num_materials) {
    return 1;
  }
  object->yz_rectangle.material = &materials[idx];
  return 0;
}

struct loaded_scene* load_scene(const char *fname) {
  FILE *f = fopen(fname, "r");

  struct loaded_scene *scene = NULL;
  size_t num_spheres, num_xy_rectangles, num_xz_rectangles, num_yz_rectangles;

  if (f == NULL) {
    goto end;
  }

  scene = malloc(sizeof(struct loaded_scene));
  scene->materials = NULL;
  scene->objects = NULL;

  if (load_vec(f, &scene->lookfrom) != 0) {
    goto error;
  }
  if (load_vec(f, &scene->lookat) != 0) {
    goto error;
  }
  if (load_size_t(f, &scene->num_materials) != 0) {
    goto error;
  }
  if (load_size_t(f, &num_spheres) != 0) {
    goto error;
  }
  if (load_size_t(f, &num_xy_rectangles) != 0) {
    goto error;
  }
  if (load_size_t(f, &num_xz_rectangles) != 0) {
    goto error;
  }
  if (load_size_t(f, &num_yz_rectangles) != 0) {
    goto error;
  }
  scene->num_objects =
    num_spheres + num_xy_rectangles + num_xz_rectangles + num_yz_rectangles;
  scene->materials = calloc(scene->num_materials, sizeof(struct material));
  scene->objects = calloc(scene->num_objects, sizeof(struct object));

  for (size_t i = 0; i < scene->num_materials; i++) {
    if (load_material(f, &scene->materials[i]) != 0) {
      goto error;
    }
  }
  size_t o = 0;
  for (size_t i = 0; i < num_spheres; i++) {
    if (load_sphere(f,
                    scene->num_materials,
                    scene->materials,
                    &scene->objects[o++]) != 0){
      goto error;
    }
  }
  for (size_t i = 0; i < num_xy_rectangles; i++) {
    if (load_xy_rectangle(f,
                          scene->num_materials,
                          scene->materials,
                          &scene->objects[o++]) != 0) {
      goto error;
    }
  }
  for (size_t i = 0; i < num_xz_rectangles; i++) {
    if (load_xz_rectangle(f,
                          scene->num_materials,
                          scene->materials,
                          &scene->objects[o++]) != 0) {
      goto error;
    }
  }
  for (size_t i = 0; i < num_yz_rectangles; i++) {
    if (load_yz_rectangle(f,
                          scene->num_materials,
                          scene->materials,
                          &scene->objects[o++]) != 0) {
      goto error;
    }
  }

  goto end;

 error:
  if (scene != NULL) {
    free(scene->materials);
    free(scene->objects);
  }
  free(scene);
  scene = NULL;

 end:
  return scene;
}

static int store_int(FILE *f, int x) {
  if (fwrite(&x, sizeof(int), 1, f) != 1) {
    return 1;
  }
  return 0;
}

static int store_double(FILE *f, double x) {
  if (fwrite(&x, sizeof(double), 1, f) != 1) {
    return 1;
  }
  return 0;
}

static int store_size_t(FILE *f, size_t x) {
  if (fwrite(&x, sizeof(size_t), 1, f) != 1) {
    return 1;
  }
  return 0;
}

static int store_vec(FILE *f, struct vec v) {
  if (store_double(f, v.x) != 0) {
    return 1;
  }
  if (store_double(f, v.y) != 0) {
    return 1;
  }
  if (store_double(f, v.z) != 0) {
    return 1;
  }
  return 0;
}

static int store_material(FILE *f, struct material *material) {
  if (store_int(f, (int)material->type) != 0) {
    return 1;
  }

  switch (material->type) {
  case LAMBERTIAN:
    if (store_vec(f, material->lambertian.albedo) != 0) {
      return 1;
    }
    break;
  case METAL:
    if (store_vec(f, material->metal.albedo) != 0) {
      return 1;
    }
    if (store_double(f, material->metal.fuzz) != 0) {
      return 1;
    }
    break;
  case DIELECTRIC:
    if (store_double(f, material->dielectric.ref_idx) != 0) {
      return 1;
    }
    break;
  default:
    abort();
  }

  return 0;
}

static int store_sphere(FILE *f, struct sphere *sphere,
                        size_t materials_idx) {
  if (store_vec(f, sphere->centre) != 0) {
    return 1;
  }
  if (store_double(f, sphere->radius) != 0) {
    return 1;
  }
  if (store_size_t(f, materials_idx) != 0) {
    return 1;
  }
  return 0;
}

static int store_xy_rectangle(FILE *f, struct xy_rectangle *obj,
                        size_t materials_idx) {
  if (store_double(f, obj->x0) != 0) {
    return 1;
  }
  if (store_double(f, obj->x1) != 0) {
    return 1;
  }
  if (store_double(f, obj->y0) != 0) {
    return 1;
  }
  if (store_double(f, obj->y1) != 0) {
    return 1;
  }
  if (store_double(f, obj->k) != 0) {
    return 1;
  }
  if (store_size_t(f, materials_idx) != 0) {
    return 1;
  }
  return 0;
}

static int store_xz_rectangle(FILE *f, struct xz_rectangle *obj,
                        size_t materials_idx) {
  if (store_double(f, obj->x0) != 0) {
    return 1;
  }
  if (store_double(f, obj->x1) != 0) {
    return 1;
  }
  if (store_double(f, obj->z0) != 0) {
    return 1;
  }
  if (store_double(f, obj->z1) != 0) {
    return 1;
  }
  if (store_double(f, obj->k) != 0) {
    return 1;
  }
  if (store_size_t(f, materials_idx) != 0) {
    return 1;
  }
  return 0;
}

static int store_yz_rectangle(FILE *f, struct yz_rectangle *obj,
                        size_t materials_idx) {
  if (store_double(f, obj->y0) != 0) {
    return 1;
  }
  if (store_double(f, obj->y1) != 0) {
    return 1;
  }
  if (store_double(f, obj->z0) != 0) {
    return 1;
  }
  if (store_double(f, obj->z1) != 0) {
    return 1;
  }
  if (store_double(f, obj->k) != 0) {
    return 1;
  }
  if (store_size_t(f, materials_idx) != 0) {
    return 1;
  }
  return 0;
}

static size_t find_materials(size_t num_objects,
                             struct object *objects,
                             struct material **materials,
                             size_t *materials_idx) {
  size_t num_materials = 0;

  for (size_t i = 0; i < num_objects; i++) {
    size_t j;
    struct material *material = object_material(&objects[i]);
    for (j = 0; j < num_materials; j++) {
      if (material == materials[j]) {
        break;
      }
    }
    if (j == num_materials) {
      materials[j] = material;
      num_materials++;
    }
    materials_idx[i] = j;
  }
  return num_materials;
}

int store_scene(char* fname,
                size_t num_objects, struct object *objects,
                struct vec lookfrom, struct vec lookat) {
  FILE *f = fopen(fname, "w");

  if (f == NULL) {
    return 1;
  }

  size_t num_materials;
  struct material **materials = calloc(num_objects, sizeof(struct material));
  size_t *materials_idx = calloc(num_objects, sizeof(size_t));

  int ret = 0;

  size_t
    num_spheres = 0,
    num_xy_rectangles = 0,
    num_xz_rectangles = 0,
    num_yz_rectangles = 0;

  for (size_t i = 0; i < num_objects; i++) {
    switch (objects[i].type) {
    case SPHERE:
      num_spheres++;
      break;
    case XY_RECTANGLE:
      num_xy_rectangles++;
      break;
    case XZ_RECTANGLE:
      num_xz_rectangles++;
      break;
    case YZ_RECTANGLE:
      num_yz_rectangles++;
      break;
    default:
      abort();
    }
  }

  if (store_vec(f, lookfrom) != 0) {
    ret = 1;
    goto end;
  }

  if (store_vec(f, lookat) != 0) {
    ret = 1;
    goto end;
  }

  num_materials =
    find_materials(num_objects, objects, materials, materials_idx);

  if (store_size_t(f, num_materials) != 0) {
    ret = 1;
    goto end;
  }
  if (store_size_t(f, num_spheres) != 0) {
    ret = 1;
    goto end;
  }
  if (store_size_t(f, num_xy_rectangles) != 0) {
    ret = 1;
    goto end;
  }
  if (store_size_t(f, num_xz_rectangles) != 0) {
    ret = 1;
    goto end;
  }
  if (store_size_t(f, num_yz_rectangles) != 0) {
    ret = 1;
    goto end;
  }

  for (size_t i = 0; i < num_materials; i++) {
    store_material(f, materials[i]);
  }

  for (size_t i = 0; i < num_objects; i++) {
    if (objects[i].type == SPHERE) {
      if (store_sphere(f, &objects[i].sphere, materials_idx[i]) != 0) {
        ret = 1;
        goto end;
      }
    }
  }
  for (size_t i = 0; i < num_objects; i++) {
    if (objects[i].type == XY_RECTANGLE) {
      if (store_xy_rectangle(f, &objects[i].xy_rectangle, materials_idx[i]) != 0) {
        ret = 1;
        goto end;
      }
    }
  }
  for (size_t i = 0; i < num_objects; i++) {
    if (objects[i].type == XZ_RECTANGLE) {
      if (store_xz_rectangle(f, &objects[i].xz_rectangle, materials_idx[i]) != 0) {
        ret = 1;
        goto end;
      }
    }
  }
  for (size_t i = 0; i < num_objects; i++) {
    if (objects[i].type == YZ_RECTANGLE) {
      if (store_yz_rectangle(f, &objects[i].yz_rectangle, materials_idx[i]) != 0) {
        ret = 1;
        goto end;
      }
    }
  }

 end:
  free(materials);
  free(materials_idx);
  fclose(f);
  return ret;
}
