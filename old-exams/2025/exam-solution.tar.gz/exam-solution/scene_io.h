#pragma once

#include "scene.h"

// A loaded scene. This is an opaque struct whose definition is hidden, to allow
// the implementation to be whatever you wish.
struct loaded_scene;

// Retrieve the number of objects in a loaded scene.
size_t scene_get_num_objects(struct loaded_scene*);

// Retrieve the objects corresponding to a loaded scene.
struct object* scene_get_objects(struct loaded_scene*);

// Retrieve the camera position from a loaded scene.
struct vec* scene_get_lookfrom(struct loaded_scene*);

// Retrieve the camera target from a loaded scene.
struct vec* scene_get_lookat(struct loaded_scene*);

// Load a scene from the given file. Returns NULL on error, including when the
// file cannot be read, or does not contain a valid scene.
struct loaded_scene* load_scene(const char *);

// Store a scene in a file. Returns 0 on success.
//
// The scene contains the given objects (and implicitly the materials they
// reference), as well as the provided lookfrom/lookat positions.
int store_scene(char* fname,
                size_t num_objects, struct object *objects,
                struct vec lookfrom, struct vec lookat);

// Deallocate any memory referenced by a loaded scene.
void free_loaded_scene(struct loaded_scene*);
