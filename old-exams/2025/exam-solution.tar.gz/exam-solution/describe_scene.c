#include <assert.h>
#include <stdio.h>
#include "scene.h"
#include "scene_io.h"

int main(int argc, char** argv) {
  // We expect a single argument: a file from which to load a scene.
  assert(argc == 2);

  // Load a scene from the given file.
  struct loaded_scene *scene = load_scene(argv[1]);

  // Abort if loading failed.
  assert(scene != NULL);

  // Retrieve the number of objects in the scene.
  size_t num_objects = scene_get_num_objects(scene);

  // Retrieve the pointer to the objects in the scene.
  struct object* objects = scene_get_objects(scene);

  // Iterate through all the objects and describe them.
  for (size_t i = 0; i < num_objects; i++) {
    describe_object(&objects[i]);
  }

  // Free the scene to avoid leaking memory.
  free_loaded_scene(scene);
}
