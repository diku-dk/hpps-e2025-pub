// A program for comparing PPM images. It does not check for strict equality
// (this could be done with cmp(1)), but allows for some fudging.

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <assert.h>

void read_ppm(const char *fname, int* width_out, int* height_out, uint32_t **pixels_out) {
  FILE* f = fopen(fname, "rb");
  assert(f != NULL);
  fscanf(f, "P6\n%d %d\n255\n", width_out, height_out);
  int num_pixels = *width_out * *height_out;

  uint32_t *pixels = calloc(num_pixels*3, sizeof(uint32_t));
  for (int i = 0; i < num_pixels; i++) {
    int r = fgetc(f);
    assert (r != EOF);
    int g = fgetc(f);
    assert (g != EOF);
    int b = fgetc(f);
    assert (b != EOF);
    pixels[i] = (r<<16) | (g<<8) | b;
  }
  *pixels_out = pixels;
}

void compare_pixels(int num_pixels, uint32_t *pixels_a, uint32_t *pixels_b) {
  double eps = 0.1;
  int mismatches = 0;

  for (int i = 0; i < num_pixels; i++) {
    double r_a = ((pixels_a[i]>>16)&0xff)/255.0;
    double r_b = ((pixels_b[i]>>16)&0xff)/255.0;
    double g_a = ((pixels_a[i]>>8)&0xff)/255.0;
    double g_b = ((pixels_b[i]>>8)&0xff)/255.0;
    double b_a = (pixels_a[i]&0xff)/255.0;
    double b_b = (pixels_b[i]&0xff)/255.0;


    if (fabs(r_a - r_b) > eps) {
      mismatches++;
    }
    if (fabs(g_a - g_b) > eps) {
      mismatches++;
    }
    if (fabs(b_a - b_b) > eps) {
      mismatches++;
    }
  }

  printf("Mismatches: %d out of %d (%f%%)\n", mismatches, num_pixels*3, mismatches/(num_pixels*3.0)*100);
}

int main(int argc, char** argv) {
  assert(argc == 3);

  int width_a, width_b, height_a, height_b;
  uint32_t *pixels_a, *pixels_b;

  printf("Loading %s...\n", argv[1]);
  read_ppm(argv[1], &width_a, &height_a, &pixels_a);
  printf("Loading %s...\n", argv[2]);
  read_ppm(argv[2], &width_b, &height_b, &pixels_b);

  if (width_a != width_b) {
    printf("Width mismatch: %d != %d\n", width_a, width_b);
    exit(1);
  }
  if (height_a != height_b) {
    printf("Height mismatch: %d != %d\n", height_a, height_b);
    exit(1);
  }

  compare_pixels(width_a*width_b, pixels_a, pixels_b);

  free(pixels_a);
  free(pixels_b);
}
